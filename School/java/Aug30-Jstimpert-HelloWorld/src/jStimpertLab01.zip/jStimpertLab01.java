// Joshua Stimpert
// Lab 1: Hello world program
// Aug 30, 2016
public class jStimpertLab01 {

	public static void main(String[] args) {
		System.out.println("Hello World from Joshua Stimpert");
		
	}

}
