//Joshua Stimpert - week 2 lab - Web Development with javascript Fall 2019 javascript

let blanket = "images/blanket.jpg";
let bluestem = "images/bluestem.jpg";
let rugosa = "images/rugosa.jpg";
