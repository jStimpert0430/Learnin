//Joshua Stimpert - Web Development with Javascript Fall 2019 - Exam 1 - Conversion Tool

function convert(){
  const farenheit = document.getElementById("fValue").value;

  const celsius = Math.round(((farenheit - 32) * 5/9), 2);
  var workingElement = document.getElementById("cValue");

  workingElement.innerHTML =celsius + "°C";
  workingElement.style.opacity =1;

  //Change colors of the text if the tempeture is hot or cold.
  if(celsius < 10){
    workingElement.style.color = "blue";
  }
  else if (celsius > 9 && celsius < 20) {
    workingElement.style.color = "white";
  }
  else{
    workingElement.style.color ="red";
  }
}

document.getElementById("button").addEventListener("click", convert, false);
