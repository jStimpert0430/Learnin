//Joshua Stimpert - Web Development with Javascript Fall 2019 - Exam 1

//Create variable and log length
let name = 'Joshua';
let dayOfBirh = 30;

console.log(name.length);

//Multiple Variables
let a = 1;
//let a = 2;
//let a = 3;
//I encountered a syntax error in the console when trying to declare the second variable with the same name.

console.log(a);

//prompt
let color = prompt('Please enter your name!');
console.log("The color you entered was \" " + color + "\"")

//String with single and double quotes
let myString = 'This is a string with both \'single quotes\' and \"double quotes\"!';
console.log(myString);

//What is the difference between null and undefined?
document.write("What is the difference between null and undefined? <br><br>Undefined is when a variable that has been declared, but has not yet recieved a value while a null value is an assigned value which represents no value<br><br><br>");

//What is NaN in javascript? what is the typeof NaN?
document.write("What is NaN in javascript? What is the typeof Nan? <br><br>NaN in javascript stands for Not a Number and is used for representing an undefined value(e.x. division by 0); The Typeof NaN is the numeric data type \'number\'<br><br><br> ");
