//Joshua Stimpert - Web Development with Javascript Fall 2019 - Exam 1 - Conversion Tool

function convert(){
  const unit = 0.453592;
  const lbs = document.getElementById("lbValue").value;

  const kgs = Math.round((unit * lbs), 2);

  document.getElementById("kgValue").innerHTML =kgs + "kgs";
  document.getElementById("kgValue").style.opacity =1;
}

document.getElementById("button").addEventListener("click", convert, false);
