//Week 3 quiz -- Joshua Stimpert -- Fall 2019

/*
1. What is the outcome of this statement
--The length of the string 'hi!' will be printed in the log and equate to the integer '3'

2. What two are considered boolean types?
--true false

3. What is the outcome of this statement?
--'Hello world' would be printed in the console

4. given the variable x is initially equal to 5, which statement will reassign x to 10?
-- x*=2

5. What is the correct way to declare a variable that you can change?
-- let myName = 'Mickey';

6. what are variables used for in JavaScript
-- for storing or holding data

7. What is the correct way to call a string's built in method?
-- 'javascript'.toUpperCase();

8. what is string interpolation?
-- When you insert the value of a variable into a string

9.Which of the code snippets would cause an error?
--(Const food = 'chicken -> food = pizza;) The programmer is trying to set a constant value after it has already beed declared here'

10. What is the correct way to call the random method in the Math library?
--Math.random()
*/
