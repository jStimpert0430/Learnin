//Joshua Stimpert - Week 11 GA - Web Development with Javascript - Fall 2019


const box = document.querySelector('.box');
//box.style.display = 'none';


//$jQuery('.box').hide();

//box.addEventListener('click', function(){
//  alert('You clicked me!');
//})

$('.box').click(function(){
  alert('You clicked me with jQuery');
})
