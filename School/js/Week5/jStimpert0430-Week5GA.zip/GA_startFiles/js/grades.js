//Joshua Stimpert -- Week 5 GA -- Fall 2019 -- Grades script

curGrade = 87;

if(curGrade >= 90){
  console.log("A");
}

else if(curGrade >= 80){
  console.log("B");
}

else if(curGrade >= 70){
  console.log("C");
}

else if(curGrade >= 70){
    console.log("D");
}

else{
  console.log("F");
}
