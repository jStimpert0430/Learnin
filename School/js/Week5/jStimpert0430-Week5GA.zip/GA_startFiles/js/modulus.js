//Joshua Stimpert -- Week 5 GA -- Fall 2019 -- Modulus Script

let num = prompt("Please enter a whole number");
if(num % 2 == 0){
  console.log("The num variable is even!");
}
else if(num % 2 == 1){
  console.log("the num variable is odd!");
}
else{
  console.log("Hey! I asked for a whole number!");
}
