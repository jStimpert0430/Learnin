// Joshua Stimpert - Week 5 GA - Fall 2019 - Loops Script
for(let i = 0; i < 10; i++){
  console.log(i);
}

i = 0;

while( i < 10){
  console.log(i);
  i++;
}
